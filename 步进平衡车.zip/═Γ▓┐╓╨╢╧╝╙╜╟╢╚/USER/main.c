#include "sys.h" 

int Moto1,Moto2,Final_Moto1,Final_Moto2;

extern float Pitch,Roll; 


void EXTI3_IRQHandler(void)
{
	Read_DMP();
	 printf("%f\r\n",Pitch);
	EXTI_ClearITPendingBit(EXTI_Line3);  
}
int main()
{
	delay_init();
	uart_init(115200);
	EXTIX_Init();
	IIC_Init();
	DMP_Init();

   // MiniBalance_Motor_Init();       
   // MiniBalance_PWM_Init();         

	//Final_Moto1 = 240;//10KHz
    //Final_Moto1 = 65535;//36Hz
    //Final_Moto2 = 65535;
	
	while(1)
	{
	  
	}
}
