#include "sys.h" 

int Moto1,Moto2,Final_Moto1,Final_Moto2;
float value = 0.0;

int main()
{
	delay_init();
    MiniBalance_Motor_Init();       
    MiniBalance_PWM_Init();         
//	
//	Final_Moto1 = 300;
//	Final_Moto2 = 300;
	//Final_Moto1 = 240;//10KHz
	Final_Moto1 = 65535;//36Hz
	Final_Moto2 = 65535;
	
	while(1)
	{
	
	}
}
