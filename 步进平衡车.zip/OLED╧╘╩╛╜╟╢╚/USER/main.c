#include "sys.h" 

int Moto1,Moto2,Final_Moto1,Final_Moto2;

extern float Pitch,Roll; 


void oled_Show(void)
{
	float Pitch_Data = 0.0;
	
	Pitch_Data = Pitch;
    OLED_Display_On();  
    OLED_ShowString(0,20,"Pitch");
	
		if(Pitch<0)		
		{
			OLED_ShowString(70,20,"-");
			OLED_ShowNumber(75,20,-Pitch_Data,3,16);
		}
		else					        		
		{
			OLED_ShowString(70,20," ");
			OLED_ShowNumber(75,20,Pitch_Data,3,16);
		}
		OLED_Refresh_Gram();
}


void EXTI3_IRQHandler(void)
{
	Read_DMP();
    ANO_DT_Send_Status(Pitch);
	EXTI_ClearITPendingBit(EXTI_Line3);  
}



int main()
{
	
	delay_init();
	uart_init(115200);
	EXTIX_Init();
	IIC_Init();
	DMP_Init();
    OLED_Init();
	
   // MiniBalance_Motor_Init();       
   // MiniBalance_PWM_Init();         

	//Final_Moto1 = 240;//10KHz
    //Final_Moto1 = 65535;//36Hz
    //Final_Moto2 = 65535;
	
	while(1)
	{
	   oled_Show();
	
	}
}
