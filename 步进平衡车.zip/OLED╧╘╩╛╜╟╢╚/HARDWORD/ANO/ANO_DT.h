#ifndef __ANO_DT_H
#define __ANO_DT_H


void ANO_DT_Send_Status(float angle_rol);

#endif
