#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
 void Get_Angle(void);
 u16  Linear_Conversion(int moto);
 int balance(float Angle ,float Gyro);
 void Xianfu_Pwm(void);
 void Set_Pwm(int moto1,int moto2);
#endif
